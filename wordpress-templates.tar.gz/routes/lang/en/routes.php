<?php
return [
  'templates' => 'vorlagen',
  'template_show' => 'vorlagen',
];
