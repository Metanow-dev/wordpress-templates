<?php
return [
  'templates' => 'templates',
  'template_show' => 'templates',
];
